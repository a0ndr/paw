#!/usr/bin/env sh
  echo 'Configuring'
